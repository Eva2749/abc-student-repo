![sample](sample.png)

# Description
This project is designed for someone to change the background of the website as he/she likes. The interaction is simple. You just click on the image and the website you are at now will change its background to the image you just clicked. At the bottom you'll find one line that states which season is your favorite one. The season that will appear is the one that you clicked most. 
